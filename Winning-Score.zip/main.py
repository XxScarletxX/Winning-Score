
three_point= 3
two_point=2
one_point=1
team_1= "the Apples"
team_2 = "the Bananas"

team_1_three_points = three_point* 10
team_1_two_points = two_point* 3
team_1_one_point = one_point*7
team_2_three_points = three_point*8
team_2_two_points = two_point*9
team_2_one_point=one_point *6

team_1 = team_1_three_points + team_1_two_points + team_1_one_point
team_2 = team_2_three_points + team_2_two_points + team_2_one_point



if (team_1 > team_2):
	print("A")
else:
	print("B")
print ("The Apples scored 10 · 3 + 3 · 2 + 7 · 1 = 43 points and the Bananas scored 8 · 3 + 9 · 2 + 6 · 1 = 48 points, and thus the Bananas won.")

team_1_three_points = three_point* 7
team_1_two_points = two_point* 3
team_1_one_point = one_point*0
team_2_three_points = three_point*6
team_2_two_points = two_point*4
team_2_one_point=one_point *1

team_1 = team_1_three_points + team_1_two_points + team_1_one_point
team_2 = team_2_three_points + team_2_two_points + team_2_one_point

if (team_1 > team_2):
	print("A")
elif (team_2 > team_1) :
	print("B")
else :
  print("T")

print ("The Apples scored 7 · 3 + 3 · 2 + 0 · 1 = 27 points and the Bananas scored 6 · 3 + 4 · 2 + 1 · 1 = 27 points, and thus it was a tie game." )


